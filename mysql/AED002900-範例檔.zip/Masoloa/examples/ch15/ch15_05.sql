ALTER PROCEDURE cmdev.gen_top_emp
    SQL SECURITY INVOKER
    COMMENT 'This is my first stored routin'
