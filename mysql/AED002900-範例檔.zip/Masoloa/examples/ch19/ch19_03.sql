mysqldump -u root cmdev


mysqldump --user=root --result-file=cmdev.sql cmdev


mysqldump -u root --tab=C:/cmdev/data/out cmdev dept
