CREATE FUNCTION summary_while (p_num INT) RETURNS INT
BEGIN
    DECLARE v_count INT DEFAULT 1;
    DECLARE v_total INT DEFAULT 0;
    WHILE v_count <= p_num DO
        SET v_total = v_total + v_count;
        SET v_count = v_count + 1;
    END WHILE;
    RETURN v_total;
END


CREATE FUNCTION summary_repeat (p_num INT) RETURNS INT
BEGIN
    DECLARE v_count INT DEFAULT 1;
    DECLARE v_total INT DEFAULT 0;
    REPEAT
        SET v_total = v_total + v_count;
        SET v_count = v_count + 1;
        UNTIL v_count > p_num
    END REPEAT;
    RETURN v_total;
END
